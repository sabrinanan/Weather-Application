package com.weather.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private RelativeLayout homeRL;
    private ProgressBar loadingPB;
    private TextView cityNameTV,temperatureTV,conditionTV;
    private RecyclerView weatherRV;
    private TextInputEditText cityEdt;
    private ImageView backIV,iconIV,searchIV;
    private ArrayList<WeatherRVModal>weatherRVModalArrayList;
    private WeatherRVAdapter weatherRVAdapter;
    private LocationManager locationManager;
    private int PERMISSION_CODE=1;
    private String cityName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        setContentView(R.layout.activity_main);
        homeRL =findViewById(R.id.idRLHome);
        loadingPB =findViewById(R.id.idPBLoading);
        cityNameTV =findViewById(R.id.idTCVityName);
        temperatureTV =findViewById(R.id.idTVTemperature);
        conditionTV =findViewById(R.id.idTVCondition);
        weatherRV =findViewById(R.id.idRVWeather);
        cityEdt =findViewById(R.id.idEdtCity);
        iconIV =findViewById(R.id.idIVIcon);
        searchIV =findViewById(R.id.idIVSearch);
        weatherRVModalArrayList = new ArrayList<>();
        weatherRVAdapter = new WeatherRVAdapter(this, weatherRVModalArrayList);
        weatherRV.setAdapter(weatherRVAdapter);
        locationManager = (LocationManager) getSystemService(context.LOCATION_SERVICE);
        cityName= getCityName(location.getLongeitude(),location.getLatitude());

    }
    private String getCityName(double longitude, double latitude){
        String cityName ="Not Found";
        Geocoder gcd = new Geocoder(getBaseContext(), Locale.getDefault());
        try {
            List<Address>addresses = gcd.getFromLocation(latitude,longitude,10)
                    for (Address adr : addresses)
                        if (adr!=null){
                            String city= adr.getLocality();
                            if(city!=null && !city.equals("")){
                                cityName= city;
                            } else {
                                Log.d("TAG", "CITY NOT FOUND");
                                Toast.makeText(this, "User City Not Found..", Toast.LENGTH_SHORT).show();
                            }
                        }
        }
    } catch (IOException e)

    {
        e.printStackTrace();
    }
        return cityName;

    }
    private void getWeatherInfo(String cityName){
        String url = "http://api.weatherapi.com/v1/forecast.json?key= e887925494f54f37a16195409231312&q="+cityName+"&days=1&aqi=no&alerts=no\n"
    }
}